import express from 'express';
import fetch from 'node-fetch';
const app = express();
app.use(express.json());

const APP_ID = "1_veAmTegrzvOSXV-2bACKkdpeRrnr9MzN5UbB4B6S5s";
const API_KEY = "AIzaSyDuePoQ7DnOBMbrMiJcfSE995ARzRzFY-g";

async function load(table) {
  const r = await fetch(`https://api.appsheet.com/api/v2/apps/${APP_ID}/tables/${table}/records`, {
    headers: {
      "ApplicationAccessKey": API_KEY,
      "Content-Type": "application/json"
    }
  });
  return r.json();
}

app.get("/api/diario", async (req, res) => res.json(await load("LANÇAMENTOS")));
app.get("/api/agenda-dia", async (req, res) => res.json(await load("AGENDA DO DIA")));
app.get("/api/agenda-ss", async (req, res) => res.json(await load("AGENDA SERVIÇO SOCIAL")));

app.listen(3000, () => console.log("Backend rodando na porta 3000"));
