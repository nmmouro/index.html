export default function App() {
  return <h1>Painel Frota Conectado</h1>;
}